import sqlite3
from db import DB_NAME

class User:
    """Base User class demonstrating encapsulation and inheritance."""
    def __init__(self, user_id, username, role, campus_id):
        self.user_id = user_id
        self.username = username
        self.role = role
        self.campus_id = campus_id

    def get_dashboard(self, root):
        raise NotImplementedError("Subclasses must implement get_dashboard.")


class Lecturer(User):
    def get_dashboard(self, root):
        from gui import LecturerDashboard
        return LecturerDashboard(root, self)


class CampusAdministrator(User):
    def get_dashboard(self, root):
        from gui import AdminDashboard
        return AdminDashboard(root, self)


class SystemOperator(User):
    def get_dashboard(self, root):
        from gui import OperatorDashboard
        return OperatorDashboard(root, self)


def authenticate_user(username, password):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('SELECT id, username, role, campus_id FROM users WHERE username = ? AND password = ?', (username, password))
    row = cursor.fetchone()
    conn.close()
    
    if row:
        uid, uname, role, cid = row
        if role == "Lecturer":
            return Lecturer(uid, uname, role, cid)
        elif role == "CampusAdministrator":
            return CampusAdministrator(uid, uname, role, cid)
        elif role == "SystemOperator":
            return SystemOperator(uid, uname, role, cid)
    return None
