import sqlite3

DB_NAME = "campus_booking.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    # Campuses table with distinct booking rules
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS campuses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            max_duration INTEGER NOT NULL,
            open_hour INTEGER NOT NULL,
            close_hour INTEGER NOT NULL
        )
    ''')
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL,
            campus_id INTEGER,
            FOREIGN KEY (campus_id) REFERENCES campuses(id)
        )
    ''')
    
    # Resources table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS resources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            campus_id INTEGER NOT NULL,
            FOREIGN KEY (campus_id) REFERENCES campuses(id)
        )
    ''')
    
    # Bookings table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            resource_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            start_time TEXT NOT NULL,
            duration INTEGER NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (resource_id) REFERENCES resources(id)
        )
    ''')
    
    # Seed initial data if tables are empty
    cursor.execute('SELECT COUNT(*) FROM campuses')
    if cursor.fetchone()[0] == 0:
        campuses = [
            ("Main Campus", 4, 8, 20),
            ("Downtown Campus", 2, 9, 17),
            ("Tech Park Campus", 6, 7, 22)
        ]
        cursor.executemany('INSERT INTO campuses (name, max_duration, open_hour, close_hour) VALUES (?, ?, ?, ?)', campuses)
        
        users = [
            ("lecturer1", "pass123", "Lecturer", 1),
            ("admin1", "pass123", "CampusAdministrator", 1),
            ("operator1", "pass123", "SystemOperator", 1)
        ]
        cursor.executemany('INSERT INTO users (username, password, role, campus_id) VALUES (?, ?, ?, ?)', users)
        
        resources = [
            ("Lecture Hall 101", 1),
            ("Projector Cart A", 1),
            ("Seminar Room B", 2),
            ("Lab PC Station 10", 2),
            ("Innovation Hub Alpha", 3),
            ("Conference Room X", 3)
        ]
        cursor.executemany('INSERT INTO resources (name, campus_id) VALUES (?, ?)', resources)
        
    conn.commit()
    conn.close()

def get_connection():
    return sqlite3.connect(DB_NAME)
