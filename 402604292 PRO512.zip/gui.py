import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from db import DB_NAME
from models import authenticate_user

class LoginWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Campus Booking System - Login")
        self.root.geometry("400x350")
        self.root.resizable(False, False)
        
        style = ttk.Style()
        style.theme_use('clam')
        
        title_lbl = ttk.Label(root, text="Smart Campus System", font=("Arial", 16, "bold"))
        title_lbl.pack(pady=20)
        
        form_frame = ttk.Frame(root, padding=20)
        form_frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(form_frame, text="Username:").pack(anchor=tk.W, pady=5)
        self.user_entry = ttk.Entry(form_frame, width=30)
        self.user_entry.pack(pady=5)
        
        ttk.Label(form_frame, text="Password:").pack(anchor=tk.W, pady=5)
        self.pass_entry = ttk.Entry(form_frame, width=30, show="*")
        self.pass_entry.pack(pady=5)
        
        btn_frame = ttk.Frame(form_frame)
        btn_frame.pack(pady=20)
        
        login_btn = ttk.Button(btn_frame, text="Login", command=self.handle_login)
        login_btn.pack(side=tk.LEFT, padx=5)
        
        reg_btn = ttk.Button(btn_frame, text="Register", command=self.open_register_window)
        reg_btn.pack(side=tk.LEFT, padx=5)

    def handle_login(self):
        username = self.user_entry.get().strip()
        password = self.pass_entry.get().strip()
        
        if not username or not password:
            messagebox.showerror("Error", "Please fill in all fields.")
            return
            
        user = authenticate_user(username, password)
        if user:
            messagebox.showinfo("Success", f"Welcome back, {user.username} ({user.role})!")
            self.root.destroy()
            
            dash_root = tk.Tk()
            user.get_dashboard(dash_root)
            dash_root.mainloop()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password.")

    def open_register_window(self):
        reg_win = tk.Toplevel(self.root)
        reg_win.title("Register New User")
        reg_win.geometry("350x400")
        
        ttk.Label(reg_win, text="Register Account", font=("Arial", 14, "bold")).pack(pady=15)
        
        frame = ttk.Frame(reg_win, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(frame, text="Username:").pack(anchor=tk.W)
        u_entry = ttk.Entry(frame, width=25)
        u_entry.pack(pady=5)
        
        ttk.Label(frame, text="Password:").pack(anchor=tk.W)
        p_entry = ttk.Entry(frame, width=25, show="*")
        p_entry.pack(pady=5)
        
        ttk.Label(frame, text="Role:").pack(anchor=tk.W)
        role_combo = ttk.Combobox(frame, values=["Lecturer", "CampusAdministrator", "SystemOperator"], state="readonly")
        role_combo.set("Lecturer")
        role_combo.pack(pady=5)
        
        ttk.Label(frame, text="Campus:").pack(anchor=tk.W)
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT id, name FROM campuses")
        campuses = cursor.fetchall()
        conn.close()
        
        campus_dict = {name: cid for cid, name in campuses}
        campus_combo = ttk.Combobox(frame, values=list(campus_dict.keys()), state="readonly")
        if campuses:
            campus_combo.set(campuses[0][1])
        campus_combo.pack(pady=5)
        
        def save_registration():
            uname = u_entry.get().strip()
            pword = p_entry.get().strip()
            urole = role_combo.get()
            selected_campus = campus_combo.get()
            
            if not uname or not pword:
                messagebox.showerror("Error", "All fields are required.")
                return
                
            cid = campus_dict.get(selected_campus, 1)
            try:
                conn = sqlite3.connect(DB_NAME)
                cursor = conn.cursor()
                cursor.execute("INSERT INTO users (username, password, role, campus_id) VALUES (?, ?, ?, ?)",
                               (uname, pword, urole, cid))
                conn.commit()
                conn.close()
                messagebox.showinfo("Success", "Registration successful! You can now log in.")
                reg_win.destroy()
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "Username already exists.")
                
        ttk.Button(frame, text="Register", command=save_registration).pack(pady=15)


class LecturerDashboard:
    def __init__(self, root, lecturer):
        self.root = root
        self.lecturer = lecturer
        self.root.title(f"Lecturer Dashboard - {lecturer.username}")
        self.root.geometry("750x550")
        
        self.conn = sqlite3.connect(DB_NAME)
        self.cursor = self.conn.cursor()
        
        top_frame = ttk.Frame(root, padding=10)
        top_frame.pack(fill=tk.X)
        
        ttk.Label(top_frame, text=f"Logged in as: {lecturer.username} (Lecturer)", font=("Arial", 11, "bold")).pack(side=tk.LEFT)
        
        ttk.Label(top_frame, text="Active Campus:").pack(side=tk.LEFT, padx=(20, 5))
        self.cursor.execute("SELECT id, name FROM campuses")
        self.campuses = self.cursor.fetchall()
        self.campus_map = {name: cid for cid, name in self.campuses}
        
        self.campus_var = tk.StringVar()
        default_camp_name = next((name for cid, name in self.campuses if cid == lecturer.campus_id), self.campuses[0][1])
        self.campus_var.set(default_camp_name)
        
        self.campus_dropdown = ttk.Combobox(top_frame, textvariable=self.campus_var, values=list(self.campus_map.keys()), state="readonly")
        self.campus_dropdown.pack(side=tk.LEFT)
        self.campus_dropdown.bind("<<ComboboxSelected>>", self.on_campus_changed)
        
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.tab_book = ttk.Frame(self.notebook)
        self.tab_history = ttk.Frame(self.notebook)
        
        self.notebook.add(self.tab_book, text="Book Resource")
        self.notebook.add(self.tab_history, text="My Bookings")
        
        self.setup_booking_tab()
        self.setup_history_tab()

    def on_campus_changed(self, event=None):
        selected_name = self.campus_var.get()
        cid = self.campus_map[selected_name]
        self.cursor.execute("SELECT id, name FROM resources WHERE campus_id = ?", (cid,))
        resources = self.cursor.fetchall()
        self.res_combo['values'] = [r[1] for r in resources]
        self.res_map = {r[1]: r[0] for r in resources}
        if resources:
            self.res_combo.set(resources[0][1])
        else:
            self.res_combo.set('')

    def setup_booking_tab(self):
        frame = ttk.Frame(self.tab_book, padding=20)
        frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(frame, text="Select Resource to Book", font=("Arial", 12, "bold")).grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=10)
        
        ttk.Label(frame, text="Resource:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.res_combo = ttk.Combobox(frame, state="readonly", width=30)
        self.res_combo.grid(row=1, column=1, sticky=tk.W, pady=5)
        
        ttk.Label(frame, text="Date (YYYY-MM-DD):").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.date_entry = ttk.Entry(frame, width=32)
        self.date_entry.insert(0, datetime.now().strftime("%Y-%m-%d"))
        self.date_entry.grid(row=2, column=1, sticky=tk.W, pady=5)
        
        ttk.Label(frame, text="Start Time (HH:MM):").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.time_entry = ttk.Entry(frame, width=32)
        self.time_entry.insert(0, "09:00")
        self.time_entry.grid(row=3, column=1, sticky=tk.W, pady=5)
        
        ttk.Label(frame, text="Duration (Hours):").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.duration_entry = ttk.Entry(frame, width=32)
        self.duration_entry.insert(0, "1")
        self.duration_entry.grid(row=4, column=1, sticky=tk.W, pady=5)
        
        ttk.Button(frame, text="Submit Booking", command=self.book_resource).grid(row=5, column=1, sticky=tk.E, pady=20)
        
        self.on_campus_changed()

    def setup_history_tab(self):
        frame = ttk.Frame(self.tab_history, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ("ID", "Campus", "Resource", "Date", "Start Time", "Duration")
        self.tree = ttk.Treeview(frame, columns=columns, show="headings")
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100)
        self.tree.pack(fill=tk.BOTH, expand=True, side=tk.TOP, pady=10)
        
        ttk.Button(frame, text="Cancel Selected Booking", command=self.cancel_booking).pack(side=tk.RIGHT)
        
        self.load_my_bookings()

    def load_my_bookings(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        self.cursor.execute('''
            SELECT b.id, c.name, r.name, b.date, b.start_time, b.duration
            FROM bookings b
            JOIN resources r ON b.resource_id = r.id
            JOIN campuses c ON r.campus_id = c.id
            WHERE b.user_id = ?
        ''', (self.lecturer.user_id,))
        for row in self.cursor.fetchall():
            self.tree.insert("", tk.END, values=row)

    def book_resource(self):
        res_name = self.res_combo.get()
        date_str = self.date_entry.get().strip()
        time_str = self.time_entry.get().strip()
        dur_str = self.duration_entry.get().strip()
        
        if not res_name or not date_str or not time_str or not dur_str:
            messagebox.showerror("Error", "All booking fields are required.")
            return
            
        try:
            duration = int(dur_str)
            if duration <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Duration must be a positive integer.")
            return
            
        selected_campus_name = self.campus_var.get()
        cid = self.campus_map[selected_campus_name]
        
        self.cursor.execute("SELECT max_duration, open_hour, close_hour FROM campuses WHERE id = ?", (cid,))
        max_dur, open_h, close_h = self.cursor.fetchone()
        
        if duration > max_dur:
            messagebox.showerror("Rule Violation", f"Booking duration exceeds maximum allowed limit of {max_dur} hours for {selected_campus_name}.")
            return
            
        try:
            t_obj = datetime.strptime(time_str, "%H:%M")
            start_hour = t_obj.hour
            start_min = t_obj.minute
        except ValueError:
            messagebox.showerror("Error", "Invalid time format. Use HH:MM in 24-hour format.")
            return
            
        if start_hour < open_h or (start_hour + duration) > close_h:
            messagebox.showerror("Rule Violation", f"Campus operating hours are from {open_h}:00 to {close_h}:00.")
            return
            
        res_id = self.res_map[res_name]
        
        new_start_mins = start_hour * 60 + start_min
        new_end_mins = new_start_mins + (duration * 60)
        
        self.cursor.execute("SELECT start_time, duration FROM bookings WHERE resource_id = ? AND date = ?", (res_id, date_str))
        existing_bookings = self.cursor.fetchall()
        
        for ex_time, ex_dur in existing_bookings:
            ex_t_obj = datetime.strptime(ex_time, "%H:%M")
            ex_start_mins = ex_t_obj.hour * 60 + ex_t_obj.minute
            ex_end_mins = ex_start_mins + (ex_dur * 60)
            
            if max(new_start_mins, ex_start_mins) < min(new_end_mins, ex_end_mins):
                messagebox.showerror("Conflict", "This resource is already booked during the requested time slot.")
                return
                
        self.cursor.execute("INSERT INTO bookings (user_id, resource_id, date, start_time, duration) VALUES (?, ?, ?, ?, ?)",
                            (self.lecturer.user_id, res_id, date_str, time_str, duration))
        self.conn.commit()
        messagebox.showinfo("Success", "Resource successfully booked!")
        self.load_my_bookings()

    def cancel_booking(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showerror("Error", "Please select a booking to cancel.")
            return
            
        booking_id = self.tree.item(selected_item)['values'][0]
        self.cursor.execute("DELETE FROM bookings WHERE id = ? AND user_id = ?", (booking_id, self.lecturer.user_id))
        self.conn.commit()
        messagebox.showinfo("Success", "Booking cancelled successfully.")
        self.load_my_bookings()


class AdminDashboard:
    def __init__(self, root, admin):
        self.root = root
        self.admin = admin
        self.root.title(f"Campus Admin Dashboard - ID: {admin.campus_id}")
        self.root.geometry("750x500")
        
        self.conn = sqlite3.connect(DB_NAME)
        self.cursor = self.conn.cursor()
        
        self.cursor.execute("SELECT name FROM campuses WHERE id = ?", (admin.campus_id,))
        self.campus_name = self.cursor.fetchone()[0]
        
        ttk.Label(root, text=f"Administrator Portal - {self.campus_name}", font=("Arial", 14, "bold")).pack(pady=10)
        
        notebook = ttk.Notebook(root)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.tab_res = ttk.Frame(notebook)
        self.tab_bookings = ttk.Frame(notebook)
        
        notebook.add(self.tab_res, text="Manage Resources")
        notebook.add(self.tab_bookings, text="Campus Bookings & Usage")
        
        self.setup_resources_tab()
        self.setup_bookings_tab()

    def setup_resources_tab(self):
        frame = ttk.Frame(self.tab_res, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ("ID", "Resource Name")
        self.res_tree = ttk.Treeview(frame, columns=columns, show="headings")
        for col in columns:
            self.res_tree.heading(col, text=col)
        self.res_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        control_frame = ttk.Frame(frame)
        control_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=10)
        
        ttk.Label(control_frame, text="Add New Resource", font=("Arial", 11, "bold")).pack(pady=5)
        self.new_res_entry = ttk.Entry(control_frame, width=20)
        self.new_res_entry.pack(pady=5)
        ttk.Button(control_frame, text="Add Resource", command=self.add_resource).pack(pady=5)
        
        ttk.Separator(control_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=20)
        ttk.Button(control_frame, text="Remove Selected", command=self.remove_resource).pack(pady=5)
        
        self.load_resources()

    def load_resources(self):
        for item in self.res_tree.get_children():
            self.res_tree.delete(item)
        self.cursor.execute("SELECT id, name FROM resources WHERE campus_id = ?", (self.admin.campus_id,))
        for row in self.cursor.fetchall():
            self.res_tree.insert("", tk.END, values=row)

    def add_resource(self):
        name = self.new_res_entry.get().strip()
        if not name:
            messagebox.showerror("Error", "Resource name cannot be empty.")
            return
        self.cursor.execute("INSERT INTO resources (name, campus_id) VALUES (?, ?)", (name, self.admin.campus_id))
        self.conn.commit()
        self.new_res_entry.delete(0, tk.END)
        messagebox.showinfo("Success", "Resource added successfully.")
        self.load_resources()

    def remove_resource(self):
        selected = self.res_tree.selection()
        if not selected:
            messagebox.showerror("Error", "Please select a resource to remove.")
            return
        res_id = self.res_tree.item(selected)['values'][0]
        self.cursor.execute("DELETE FROM bookings WHERE resource_id = ?", (res_id,))
        self.cursor.execute("DELETE FROM resources WHERE id = ?", (res_id,))
        self.conn.commit()
        messagebox.showinfo("Success", "Resource removed.")
        self.load_resources()
        self.load_campus_bookings()

    def setup_bookings_tab(self):
        frame = ttk.Frame(self.tab_bookings, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ("Booking ID", "Lecturer", "Resource", "Date", "Start Time", "Duration")
        self.book_tree = ttk.Treeview(frame, columns=columns, show="headings")
        for col in columns:
            self.book_tree.heading(col, text=col)
        self.book_tree.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.stats_lbl = ttk.Label(frame, text="", font=("Arial", 10, "bold"))
        self.stats_lbl.pack(anchor=tk.W, pady=5)
        
        self.load_campus_bookings()

    def load_campus_bookings(self):
        for item in self.book_tree.get_children():
            self.book_tree.delete(item)
            
        self.cursor.execute('''
            SELECT b.id, u.username, r.name, b.date, b.start_time, b.duration
            FROM bookings b
            JOIN users u ON b.user_id = u.id
            JOIN resources r ON b.resource_id = r.id
            WHERE r.campus_id = ?
        ''', (self.admin.campus_id,))
        rows = self.cursor.fetchall()
        for row in rows:
            self.book_tree.insert("", tk.END, values=row)
            
        total_bookings = len(rows)
        self.stats_lbl.config(text=f"Total Active Bookings for {self.campus_name}: {total_bookings}")


class OperatorDashboard:
    def __init__(self, root, operator):
        self.root = root
        self.operator = operator
        self.root.title("System Operator Dashboard - Global Oversight")
        self.root.geometry("800x550")
        
        self.conn = sqlite3.connect(DB_NAME)
        self.cursor = self.conn.cursor()
        
        ttk.Label(root, text="System Operator Global View & Reports", font=("Arial", 14, "bold")).pack(pady=10)
        
        notebook = ttk.Notebook(root)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        tab_global = ttk.Frame(notebook)
        tab_report = ttk.Frame(notebook)
        
        notebook.add(tab_global, text="All Campus Bookings")
        notebook.add(tab_report, text="Comparative Reports")
        
        g_frame = ttk.Frame(tab_global, padding=10)
        g_frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ("ID", "Campus", "Resource", "User", "Date", "Start Time", "Duration")
        self.global_tree = ttk.Treeview(g_frame, columns=columns, show="headings")
        for col in columns:
            self.global_tree.heading(col, text=col)
        self.global_tree.pack(fill=tk.BOTH, expand=True, pady=10)
        
        ttk.Button(g_frame, text="Refresh Data", command=self.load_global_data).pack(side=tk.RIGHT)
        
        r_frame = ttk.Frame(tab_report, padding=20)
        r_frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(r_frame, text="Campus Usage Comparison Summary", font=("Arial", 12, "bold")).pack(anchor=tk.W, pady=5)
        
        self.report_text = tk.Text(r_frame, height=15, width=80)
        self.report_text.pack(pady=10)
        
        ttk.Button(r_frame, text="Generate Comparative Report", command=self.generate_report).pack(anchor=tk.W)
        
        self.load_global_data()
        self.generate_report()

    def load_global_data(self):
        for item in self.global_tree.get_children():
            self.global_tree.delete(item)
            
        self.cursor.execute('''
            SELECT b.id, c.name, r.name, u.username, b.date, b.start_time, b.duration
            FROM bookings b
            JOIN resources r ON b.resource_id = r.id
            JOIN campuses c ON r.campus_id = c.id
            JOIN users u ON b.user_id = u.id
        ''')
        for row in self.cursor.fetchall():
            self.global_tree.insert("", tk.END, values=row)

    def generate_report(self):
        self.report_text.delete("1.0", tk.END)
        
        report_lines = []
        report_lines.append("=== SMART CAMPUS SYSTEM COMPARATIVE REPORT ===")
        report_lines.append(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        
        self.cursor.execute("SELECT id, name, max_duration, open_hour, close_hour FROM campuses")
        campuses = self.cursor.fetchall()
        
        for cid, cname, max_dur, open_h, close_h in campuses:
            report_lines.append(f"Campus: {cname}")
            report_lines.append(f" - Operating Hours: {open_h}:00 - {close_h}:00")
            report_lines.append(f" - Max Booking Duration: {max_dur} hours")
            
            self.cursor.execute("SELECT COUNT(*) FROM resources WHERE campus_id = ?", (cid,))
            res_count = self.cursor.fetchone()[0]
            report_lines.append(f" - Total Resources: {res_count}")
            
            self.cursor.execute('''
                SELECT COUNT(*) FROM bookings b
                JOIN resources r ON b.resource_id = r.id
                WHERE r.campus_id = ?
            ''', (cid,))
            booking_count = self.cursor.fetchone()[0]
            report_lines.append(f" - Total Bookings Made: {booking_count}")
            report_lines.append("-" * 45)
            
        self.report_text.insert(tk.END, "\n".join(report_lines))
