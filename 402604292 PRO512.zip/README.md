# Smart Campus Resource Booking System (Programming 512)

A Python desktop application built with `tkinter` and `sqlite3` for managing multi-campus resource bookings.

## Project Structure
- `db.py`: Database setup, SQLite schema creation, and default seed data.
- `models.py`: Object-Oriented Programming (OOP) user models (`User`, `Lecturer`, `CampusAdministrator`, `SystemOperator`) and authentication logic.
- `gui.py`: Tkinter graphical interface containing login/registration screens and role-specific dashboards.
- `main.py`: Entry point of the application.

## How to Run

1. Make sure Python 3.x is installed.
2. Run the main script:
   ```bash
   python main.py
   ```

## Default Test Accounts
- **Lecturer**: `lecturer1` / `pass123`
- **Campus Administrator**: `admin1` / `pass123`
- **System Operator**: `operator1` / `pass123`
