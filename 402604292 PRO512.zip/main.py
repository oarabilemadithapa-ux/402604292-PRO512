import tkinter as tk
from db import init_db
from gui import LoginWindow

def main():
    # Initialize SQLite database and seed initial data
    init_db()
    
    # Launch main application window
    root = tk.Tk()
    app = LoginWindow(root)
    root.mainloop()

if __name__ == "__main__":
    main()
